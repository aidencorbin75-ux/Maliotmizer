package com.example.maligameoptimizer

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.view.ViewGroup
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var gameList: LinearLayout
    private val games = mutableListOf<GameEntry>()

    data class GameEntry(val label: String, val packageName: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Mali Game Optimizer"
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 22, 24, 28)
            setBackgroundColor(0xFF101820.toInt())
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        text("MALI GAME OPTIMIZER", 25, 0xFFFFFFFF.toInt(), true)
        text("Android game companion • v0.2.0", 14, 0xFFB9C6D2.toInt())
        text("LIVE MODE: floating companion controls and tips. This app does NOT intercept or upscale another game's live frames. Android normally prevents that without game-specific support, system privileges, or a compatible game renderer.", 14, 0xFFFFD180.toInt())
        section("DEVICE CHECK")
        val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
        val gl = am.deviceConfigurationInfo.glEsVersion ?: "Unknown"
        val vulkan = packageManager.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL) ||
                packageManager.hasSystemFeature("android.hardware.vulkan.level")
        text("Device: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nHardware: ${Build.HARDWARE}\nOpenGL ES reported: $gl\nVulkan feature advertised: ${if (vulkan) "Yes" else "Not detected"}", 14, 0xFFE8EEF2.toInt())
        text("Note: Android's public app APIs do not reliably expose the exact Mali GPU model on every phone. 'Not detected' is not proof that Vulkan is absent.", 12, 0xFFB9C6D2.toInt())

        section("LIVE COMPANION")
        button("Enable floating companion") { enableOverlayAndStart() }
        button("Stop floating companion") { stopService(Intent(this, CompanionOverlayService::class.java)); toast("Companion stopped") }
        button("Open display / refresh-rate settings") { safeSettings(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        button("Open battery settings") { safeSettings(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }

        section("PROFILE GUIDANCE")
        text("BALANCED • Mali / mobile GPU", 16, 0xFF80CBC4.toInt(), true)
        text("• Start with Medium graphics and 60 FPS if the game sustains it.\n• If heat or frame drops build up, try 30 FPS or lower shadows/effects.\n• Prefer each game's own render-scale or resolution option.\n• Keep the phone's thermal protections enabled.\n• Avoid unknown 'GPU driver' APKs and tools claiming universal DLSS.", 14, 0xFFE8EEF2.toInt())

        section("INSTALLED GAMES")
        button("Scan launchable apps") { scanGames() }
        gameList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(gameList)
        text("Choose Launch to open a game. The app cannot force that game's resolution, FPS cap, or rendering method.", 12, 0xFFB9C6D2.toInt())
    }

    private fun section(s: String) {
        root.addView(TextView(this).apply {
            text = s
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 22, 0, 8)
        })
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) {
        root.addView(TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 5, 0, 8)
        })
    }

    private fun button(label: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun enableOverlayAndStart() {
        if (Settings.canDrawOverlays(this)) {
            startService(Intent(this, CompanionOverlayService::class.java))
            toast("Floating companion started")
        } else {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"))
            startActivity(intent)
            toast("Allow display over other apps, then return and tap Enable again")
        }
    }

    private fun safeSettings(intent: Intent) {
        try { startActivity(intent) } catch (_: Exception) {
            toast("This settings page is not available on this device")
        }
    }

    private fun scanGames() {
        gameList.removeAllViews()
        games.clear()
        @Suppress("DEPRECATION")
        val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        for (app in apps) {
            if ((app.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            if (packageManager.getLaunchIntentForPackage(app.packageName) == null) continue
            games.add(GameEntry(packageManager.getApplicationLabel(app).toString(), app.packageName))
        }
        games.sortBy { it.label.lowercase() }
        if (games.isEmpty()) {
            addGameText("No launchable user apps were visible to Android.")
        } else {
            games.forEach { game ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    setPadding(0, 4, 0, 4)
                }
                val name = TextView(this).apply {
                    text = game.label
                    textSize = 14f
                    setTextColor(0xFFE8EEF2.toInt())
                }
                row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(Button(this).apply {
                    text = "Launch"
                    isAllCaps = false
                    setOnClickListener {
                        val launch = packageManager.getLaunchIntentForPackage(game.packageName)
                        if (launch != null) startActivity(launch) else toast("Game could not be launched")
                    }
                })
                gameList.addView(row)
            }
        }
        toast("Found ${games.size} visible launchable apps")
    }

    private fun addGameText(s: String) {
        gameList.addView(TextView(this).apply {
            text = s; textSize = 14f; setTextColor(0xFFE8EEF2.toInt())
        })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
