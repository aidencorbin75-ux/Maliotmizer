package com.example.maligameoptimizer

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.View
import android.view.MotionEvent
import android.view.ViewGroup

/**
 * Floating companion UI only. It cannot read another app's frame buffer or modify its renderer.
 * No fake FPS counter is shown because Android does not grant general cross-app frame telemetry.
 */
class CompanionOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var expanded = false
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (panel == null) createBubble()
        return START_NOT_STICKY
    }

    private fun createBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val bubble = TextView(this).apply {
            text = "M"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            setBackgroundColor(0xFF00695C.toInt())
            setPadding(18, 12, 18, 12)
            setOnClickListener { togglePanel() }
            contentDescription = "Mali Game Optimizer floating companion. Tap for tips."
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 180 }
        params = p
        panel = bubble
        wm.addView(bubble, p)
        bubble.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var downX = 0f
            var downY = 0f
            var dragged = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = params ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x; startY = lp.y
                        downX = e.rawX; downY = e.rawY; dragged = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - downX).toInt()
                        val dy = (e.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 8) dragged = true
                        lp.x = (startX - dx).coerceAtLeast(0)
                        lp.y = (startY + dy).coerceAtLeast(0)
                        wm.updateViewLayout(v, lp)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!dragged) togglePanel()
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun togglePanel() {
        val old = panel ?: return
        if (expanded) {
            wm.removeView(old)
            val bubble = TextView(this).apply {
                text = "M"; textSize = 20f; gravity = Gravity.CENTER
                setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
                setBackgroundColor(0xFF00695C.toInt()); setPadding(18, 12, 18, 12)
                setOnClickListener { togglePanel() }
            }
            panel = bubble
            wm.addView(bubble, params)
            expanded = false
            return
        }
        wm.removeView(old)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(0xEE101820.toInt())
        }
        box.addView(TextView(this).apply {
            text = "MALI COMPANION"
            textSize = 16f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = "Live render upscaling: NOT active. This overlay cannot intercept the game's frames. Use game-native resolution/render scale if available."
            textSize = 13f; setTextColor(0xFFFFD180.toInt()); setPadding(0, 8, 0, 8)
        })
        box.addView(TextView(this).apply {
            text = "Quick checks\n• Lower shadows and effects first\n• Try a stable 30/60 FPS cap\n• If heat rises, lower graphics\n• Keep thermal protection enabled"
            textSize = 14f; setTextColor(0xFFE8EEF2.toInt()); setPadding(0, 4, 0, 8)
        })
        box.addView(Button(this).apply {
            text = "Close panel"; isAllCaps = false
            setOnClickListener { togglePanel() }
        })
        box.addView(Button(this).apply {
            text = "Stop companion"; isAllCaps = false
            setOnClickListener { stopSelf() }
        })
        val lp = params!!
        lp.width = (resources.displayMetrics.widthPixels * 0.82f).toInt()
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        panel = box
        wm.addView(box, lp)
        expanded = true
    }

    override fun onDestroy() {
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null
        super.onDestroy()
    }
}
