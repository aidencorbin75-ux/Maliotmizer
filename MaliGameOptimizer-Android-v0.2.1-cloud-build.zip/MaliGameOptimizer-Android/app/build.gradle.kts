plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.maligameoptimizer"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.maligameoptimizer"
        minSdk = 26
        targetSdk = 32
        versionCode = 2
        versionName = "0.2.0"
    }
}
