# Mali Game Optimizer — Android source (v0.2.0)

A practical Android companion for mobile gaming, with a floating overlay, launchable-app list, device capability summary, settings shortcuts, and safe graphics guidance.

## What it really does
- Lists visible launchable third-party apps and lets you launch them.
- Offers a draggable floating companion overlay, with graphics tips while another app is foregrounded.
- Reports Android/device metadata and the OpenGL ES version advertised by Android.
- Links to display and battery settings.
- Does not require root.

## What it does NOT do
- It does not intercept another game's frame buffer or insert an upscaling pass.
- It does not claim DLSS/FSR/XeSS support and does not show fabricated FPS numbers.
- It cannot force a game to change its render resolution, FPS cap, anti-aliasing, or graphics API.
- The floating overlay is a UI overlay, not a rendering hook. Live upscaling needs game-engine integration, game-specific support, or privileged/system-level access that a normal app does not have.

## Build
Open this folder in Android Studio (recent stable version), allow Gradle sync, then Build > Build APK(s). This source has not been verified by a local Android build environment. Android Studio/Gradle may request SDK or plugin downloads.

- Android Studio / Android SDK
- JDK 17 recommended
- `compileSdk = 35`
- `minSdk = 26`
- `targetSdk = 32` in this prototype; update and test target SDK policy before release.

## Overlay permission
Tap **Enable floating companion**. Android opens the “Display over other apps” permission screen. Grant permission, return to the app, then tap the button again. Tap the floating `M` bubble for tips. Stop it from the main app or overlay panel.

## App visibility
`QUERY_ALL_PACKAGES` is used for the broad installed-app list. Google Play restricts this permission; if publishing, replace it with narrowly scoped package visibility or another compliant discovery flow.

## Limitations
This is source code, not a compiled/tested APK. Test on the target phone before relying on it. OEM background restrictions can stop the overlay service.


## Build an APK from an Android phone using GitHub Actions
This project includes `.github/workflows/build-apk.yml` so GitHub's cloud runner can build the debug APK without installing Android Studio on your phone.

1. Sign in to GitHub and create a **new empty repository**.
2. Upload the contents of this project folder to the repository (including the hidden `.github` folder). If using GitHub's web uploader, make sure `.github/workflows/build-apk.yml` is included.
3. Open the repository's **Actions** tab and select **Build Android APK**. If asked, enable Actions.
4. Tap **Run workflow** (or push to `main`/`master` to trigger the workflow).
5. When the run finishes successfully, open the run and download the `MaliGameOptimizer-debug-apk` artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.
6. On your Android phone, open the APK and allow installation from that source if Android asks.

The APK from this workflow is a debug/test build, not a Play Store release. The workflow has not been executed in this environment, so the build must be confirmed by GitHub Actions before the APK is considered built. You must trust the source before installing any APK.
